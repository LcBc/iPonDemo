'use strict';

app.home = kendo.observable({
    onShow: function() {},
    afterShow: function() {}
});

